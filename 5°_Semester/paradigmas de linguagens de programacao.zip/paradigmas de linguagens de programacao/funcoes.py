def head(list):
    return list[0]

def tail(list):
    return list[1:]
